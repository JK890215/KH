<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>크레벅스::재능마켓</title>
	<script type="text/javascript" src="../js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="../css/s_edit.css">
	<script src="../dist/semantic.js"></script>
	<link rel="stylesheet" href="../outdatedbrowser/outdatedbrowser.min.css">


	<script type="text/javascript" src="../js/global.js"></script>
	<script type="text/javascript" src="../js/member.js"></script>
	<script type="text/javascript" src="../js/shop.js"></script>
	<script type="text/javascript" src="../js/menu.js"></script>
	<script type="text/javascript" src="../js/placeholders.min.js"></script>
	<script type="text/javascript" src="http://wcs.naver.net/wcslog.js"></script><script type="text/javascript">if(!wcs_add) var wcs_add = {};wcs_add["wa"] = "1475a56d7b8754c";wcs_do();</script>

	<!--<script type="text/javascript" src="[JS library]"></script>-->
	<!--[if (gte IE 6)&(lte IE 8)]>
	  <script type="text/javascript" src="js/selectivizr.js"></script>
	  <noscript><link rel="stylesheet" href="[fallback css]" /></noscript>
	<![endif]-->
	<script src="//ajax.googleapis.com/ajax/libs/webfont/1.4.10/webfont.js"></script>
	<script type="text/javascript">
	  WebFont.load({

	    // For google fonts
	    google: {
	      families: ['Droid Sans', 'Droid Serif']
	    },
	    // For early access or custom font
	    custom: {
	        families: ['Nanum Gothic'],
	        urls: ['http://fonts.googleapis.com/earlyaccess/nanumgothic.css']
	    }

	  });
	</script>
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-66362455-1', 'auto');
	  ga('send', 'pageview');

	</script>
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '861656550550675');
fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=861656550550675&ev=PageView&noscript=1" /></noscript>
<!-- End Facebook Pixel Code -->
</head>

<body>
	<section class="bg_image" style="height: auto; min-width:1000px; position: relative; background-color: rgba(0,0,0,0.3)">
		<div id="bg" style="background:url('../images/layout/home.jpg') center center;background-size: cover; position: absolute; left:0; right:0; bottom:0; top:0; z-index: -1"></div>
		<div class="upper">
			<!-- 상단바 영역 -->
			<nav class="top_nav container">
				<a href="javascript:index();">
					<h1 class="logo float left">
						<img src="../images/layout/logo_crebugs.png" style="padding-top: 18px" alt="크레벅스 로고" width="170">
					</h1>
				</a>
				<div class="right_bottom float right">
					<div class="float left">
						<form method="get" action="../product/list.php"><input type="hidden" name="PHPSESSID" value="185dbf63c0becc7ce2f7936c9f78e021" />
							<input type="hidden" name="otype" value="" />
							<input type="hidden" name="code" value="" />
							<input type="hidden" name="mkeytype" id="mkeytype" value="p" />
							<input type="text" name="keyword" placeholder="재능 검색">
							<div class="bar"></div>
							<button class="float left search_btn"><i class="search icon"></i></button>
						</form>
					</div>
					<div class="float right">
						<ul class="icon_category">

							<li class="profile_box" >
																<a href="../member/login.php?PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021" style="padding: 7px;">로그인</a>

								<a href="../member/join.php?PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021"  style="padding: 7px;">회원가입</a>
															</li>
							<li class="side_icon side_btn">
								<div class="line"></div>
								<div class="line"></div>
								<div class="line"></div>
															</li>
						</ul>
					</div>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</nav>
			<div class="clear"></div>
			<div class="category_bg">
				<!-- 카테고리 영역 -->
				<nav class="category container">
					<ul class="list">
													<li>
								<a  href="../product/list.php?code=10&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">디자인</a>
								<ul class="sub_nav">
																<li><a href="../product/list.php?code=1010&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">로고/CI/BI</a></li>
																<li><a href="../product/list.php?code=1011&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">명함/브로셔</a></li>
																<li><a href="../product/list.php?code=1012&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">인물/캐리커쳐</a></li>
																<li><a href="../product/list.php?code=1025&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">커미션</a></li>
																<li><a href="../product/list.php?code=1013&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">만화/웹툰</a></li>
																<li><a href="../product/list.php?code=1014&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">POP/현수막</a></li>
																<li><a href="../product/list.php?code=1015&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">일러스트</a></li>
																<li><a href="../product/list.php?code=1016&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">웹디자인</a></li>
																<li><a href="../product/list.php?code=1017&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">이벤트/상세페이지</a></li>
																<li><a href="../product/list.php?code=1024&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">블로그/카페</a></li>
																<li><a href="../product/list.php?code=1018&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">폰트/캘리그라피</a></li>
																<li><a href="../product/list.php?code=1019&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">사진/포토샵</a></li>
																<li><a href="../product/list.php?code=1020&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">스케치</a></li>
																<li><a href="../product/list.php?code=1021&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">도면/3D도면</a></li>
																<li><a href="../product/list.php?code=1022&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">출판/e북</a></li>
																<li><a href="../product/list.php?code=1023&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기타</a></li>
															</ul>
							</li>
													<li>
								<a  href="../product/list.php?code=11&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">마케팅</a>
								<ul class="sub_nav">
																<li><a href="../product/list.php?code=1119&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">SNS마케팅</a></li>
																<li><a href="../product/list.php?code=1111&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">바이럴마케팅</a></li>
																<li><a href="../product/list.php?code=1110&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">마케팅 기획</a></li>
																<li><a href="../product/list.php?code=1112&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">카페/블로그</a></li>
																<li><a href="../product/list.php?code=1113&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">검색/트래픽</a></li>
																<li><a href="../product/list.php?code=1114&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">배너광고</a></li>
																<li><a href="../product/list.php?code=1115&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">야외광고</a></li>
																<li><a href="../product/list.php?code=1116&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">이메일/DM발송</a></li>
																<li><a href="../product/list.php?code=1117&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">광고대행</a></li>
																<li><a href="../product/list.php?code=1118&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기타</a></li>
															</ul>
							</li>
													<li>
								<a  href="../product/list.php?code=12&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">문서</a>
								<ul class="sub_nav">
																<li><a href="../product/list.php?code=1210&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">번역/통역</a></li>
																<li><a href="../product/list.php?code=1211&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">타이핑/문서작업</a></li>
																<li><a href="../product/list.php?code=1220&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">제안서</a></li>
																<li><a href="../product/list.php?code=1212&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">카피라이팅</a></li>
																<li><a href="../product/list.php?code=1213&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">창작/대본</a></li>
																<li><a href="../product/list.php?code=1214&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기사/리뷰</a></li>
																<li><a href="../product/list.php?code=1215&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">교정/편집</a></li>
																<li><a href="../product/list.php?code=1216&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">서식/자료</a></li>
																<li><a href="../product/list.php?code=1217&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">프레젠테이션</a></li>
																<li><a href="../product/list.php?code=1218&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">보도자료</a></li>
																<li><a href="../product/list.php?code=1219&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기타</a></li>
															</ul>
							</li>
													<li>
								<a  href="../product/list.php?code=13&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">비지니스</a>
								<ul class="sub_nav">
																<li><a href="../product/list.php?code=1310&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">창업/사업계획</a></li>
																<li><a href="../product/list.php?code=1311&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">노하우/팁</a></li>
																<li><a href="../product/list.php?code=1312&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">컨설팅/리서치</a></li>
																<li><a href="../product/list.php?code=1313&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">업무지원</a></li>
																<li><a href="../product/list.php?code=1314&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">금융/투자상담</a></li>
																<li><a href="../product/list.php?code=1315&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">법률상담</a></li>
																<li><a href="../product/list.php?code=1316&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">문서작성</a></li>
																<li><a href="../product/list.php?code=1317&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기타</a></li>
															</ul>
							</li>
													<li>
								<a  href="../product/list.php?code=14&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">컴퓨터</a>
								<ul class="sub_nav">
																<li><a href="../product/list.php?code=1410&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">웹사이트</a></li>
																<li><a href="../product/list.php?code=1413&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">모바일 사이트</a></li>
																<li><a href="../product/list.php?code=1411&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">어플리케이션</a></li>
																<li><a href="../product/list.php?code=1412&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">응용프로그램</a></li>
																<li><a href="../product/list.php?code=1414&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">컴퓨터/서버</a></li>
																<li><a href="../product/list.php?code=1415&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">플래시/스크립트</a></li>
																<li><a href="../product/list.php?code=1416&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">프로그램/매트랩</a></li>
																<li><a href="../product/list.php?code=1417&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기타</a></li>
															</ul>
							</li>
													<li>
								<a  href="../product/list.php?code=15&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">음악&amp;영상</a>
								<ul class="sub_nav">
																<li><a href="../product/list.php?code=1510&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">영상제작/편집</a></li>
																<li><a href="../product/list.php?code=1511&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">녹음/편집</a></li>
																<li><a href="../product/list.php?code=1516&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">에니메이션 제작</a></li>
																<li><a href="../product/list.php?code=1512&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">작사/작곡/채보</a></li>
																<li><a href="../product/list.php?code=1513&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">나레이션/성우</a></li>
																<li><a href="../product/list.php?code=1514&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">자막제작</a></li>
																<li><a href="../product/list.php?code=1515&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">레슨/강좌</a></li>
																<li><a href="../product/list.php?code=1518&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">비트박스</a></li>
																<li><a href="../product/list.php?code=1517&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기타</a></li>
															</ul>
							</li>
													<li>
								<a  href="../product/list.php?code=16&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">생활서비스</a>
								<ul class="sub_nav">
																<li><a href="../product/list.php?code=1610&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">개인강좌/학습</a></li>
																<li><a href="../product/list.php?code=1611&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">연애상담</a></li>
																<li><a href="../product/list.php?code=1612&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">건강/다이어트</a></li>
																<li><a href="../product/list.php?code=1613&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">상담/대화</a></li>
																<li><a href="../product/list.php?code=1624&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">사주/운세</a></li>
																<li><a href="../product/list.php?code=1614&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">생활상식/노하우</a></li>
																<li><a href="../product/list.php?code=1615&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">미용/스타일링</a></li>
																<li><a href="../product/list.php?code=1616&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">역할/하객대행</a></li>
																<li><a href="../product/list.php?code=1617&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">여행</a></li>
																<li><a href="../product/list.php?code=1618&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">가사/베이비시터</a></li>
																<li><a href="../product/list.php?code=1619&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">수리/인력/공사</a></li>
																<li><a href="../product/list.php?code=1620&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">이벤트/홍보</a></li>
																<li><a href="../product/list.php?code=1621&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">심부름</a></li>
																<li><a href="../product/list.php?code=1623&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기타</a></li>
															</ul>
							</li>
													<li>
								<a  href="../product/list.php?code=17&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">핸드메이드</a>
								<ul class="sub_nav">
																<li><a href="../product/list.php?code=1710&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">소품제작</a></li>
																<li><a href="../product/list.php?code=1711&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">의류/패션잡화</a></li>
																<li><a href="../product/list.php?code=1712&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">액세서리/쥬얼리</a></li>
																<li><a href="../product/list.php?code=1713&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">리폼</a></li>
																<li><a href="../product/list.php?code=1714&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">공예/미술</a></li>
																<li><a href="../product/list.php?code=1715&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">선물</a></li>
																<li><a href="../product/list.php?code=1716&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">카드/메세지</a></li>
																<li><a href="../product/list.php?code=1717&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">농산물/식료품</a></li>
																<li><a href="../product/list.php?code=1718&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">수집품</a></li>
																<li><a href="../product/list.php?code=1719&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기타</a></li>
															</ul>
							</li>
													<li>
								<a  href="../product/list.php?code=18&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">게임</a>
								<ul class="sub_nav">
																<li><a href="../product/list.php?code=1810&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">LOL</a></li>
																<li><a href="../product/list.php?code=1820&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">오버워치</a></li>
																<li><a href="../product/list.php?code=1817&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">히어로즈오브스톰</a></li>
																<li><a href="../product/list.php?code=1811&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">서든어택</a></li>
																<li><a href="../product/list.php?code=1816&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">하스스톤</a></li>
																<li><a href="../product/list.php?code=1818&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">던전앤파이터</a></li>
																<li><a href="../product/list.php?code=1819&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">디아블로3</a></li>
																<li><a href="../product/list.php?code=1812&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">스타크래프트</a></li>
																<li><a href="../product/list.php?code=1813&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">RPG</a></li>
																<li><a href="../product/list.php?code=1814&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">모바일게임</a></li>
																<li><a href="../product/list.php?code=1815&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">기타</a></li>
															</ul>
							</li>
												<li class="btnCategory_request" style="float:right;"><span class="select"><i class="icon cloud"></i>카테고리 요청</span></li>
					</ul>
					<div class="clear"></div>
				</nav>
			</div>
		</div> <!-- upper end -->
			</section>

<script type="text/javascript">
	$(function(){

	var bg_dir = '../images/layout/';
	var bg_item =[	'bg1.png',
					'bg2.png'
					];
	var bg_cnt = Math.floor(Math.random() * bg_item.length);

	$('#bg').css({'background-image': 'url('+bg_dir+bg_item[bg_cnt]+')'});
	});
</script>


	<div id="side_mask"></div>
	<nav class="side_nav">

		<header class="top">
			<ul id="noticeTick" style="height:60px;overflow:hidden">
							<li style="height:40px;padding:10px 0px 10px 0px;"><a href="../customer/notice.php?b_id=001&idx=124&mode=view&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">[크레벅스 패밀리]4주차 패밀리의 열정은 끝이없다! 리얼후기 만나보기!</a></li>
							<li style="height:40px;padding:10px 0px 10px 0px;"><a href="../customer/notice.php?b_id=001&idx=122&mode=view&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">[플러스 재능]여러분의 재능을 노출 하십시오!</a></li>
						</ul>
			
			<script>
				function tick() {
					$('#noticeTick li:first').slideUp( function() { $(this).appendTo( $('#noticeTick') ).slideDown(); });
				}
				
				$( function() {
					setInterval( function() { tick(); }, 3000 );
				});
			</script>
		</header>
				<section class="profile_box">
			<a href="../member/login.php?PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021" style="color:#555;display:inline-block; margin: 20px 0; font-weight:bold; font-size: 13pt !important; line-height: 13pt !importnat;">
				<i class="icon lock"></i>
				로그인을 해주세요!
			</a>
		</section>
				<section class="body">
						<header>
				<span class="title"><i class="icon alarm outline" ></i> 알림</span>
			</header>
			<section class="list alarm">

								<a class="list_item" style="margin: 5px 0; text-align:center;">
					새로운 알림이 없습니다.
				</a>
								<div class="clear"></div>
			</section>
			<div class="clear"></div>
		</section>
	</nav>


<!-- 사이드 메뉴 관련 스크립트 -->
<script type="text/javascript">

	$(function(){
		$('.side_nav section.list.msg > a.list_item:first').css('margin-top', '5px');
		$('.side_nav section.list.msg > a.list_item:last').css('border-bottom', 'none');

		$('.side_nav section.list.alarm > a.list_item:first').css('margin-top', '5px');
		$('.side_nav section.list.alarm > a.list_item:last').css('border-bottom', 'none');


		$('.msg .list_item').click(function(){
			$(this).slideUp('fast');

			$('.side_nav section.list.msg > a.list_item:first').css('margin-top', '5px');
			$('.side_nav section.list.msg > a.list_item:last').css('border-bottom', 'none');
		});

		$('.list a, .sub_nav').mouseenter(function(){
			$obj = $(this).parent().find('.sub_nav');
			$obj.css('z-index', '100').stop().slideDown('fast');
		});
		$('.list a, .sub_nav').mouseleave(function(){
			$obj = $(this).parent().find('.sub_nav');
			$obj.css('z-index', '99').stop().slideUp('fast');
		});
	});
</script>


<script type="text/javascript">
	$(function(){
		var lefts = $('.main_content .container').offset().left;
		function open_side() {
			// $('#side_mask').fadeIn(200);
			$('#side_mask').fadeTo(200,0.6);
			$('.side_nav').css('right', -100).css('opacity', 0).show();
			$('html').css('overflow', 'hidden');
			// $("body").bind('touchmove', function(e){e.preventDefault()}); //스크롤방지
			$('.side_nav').animate({right: '0px', opacity: 1}, 300);
		}
		function close_side() {
			$('.side_nav').animate({right: '-500px', opacity: 0}, 200, function(){$(this).hide();});
			$('#side_mask').fadeOut();
			$('html').css('overflow', 'auto');
			// $("body").unbind('touchmove'); //스크롤 방지 해제
		}

		$('.side_btn').click(function(){open_side();});
		$('#side_mask, .exit.btn').click(function(){close_side();});

		$('.top_nav.container .right_bottom .left input[name=keyword]').mouseenter(function(){$(this).focus();});
	});
</script>

	<!-- 컨텐츠 영역 -->
	<div class="main_content">
		<!-- 컨텐츠 컨테이너 시작 -->
		<section class="container">
<section class="left_menu list">
	<div class="title">회원가입</div>
	<div class="sub_title">HOME  <i class="angle right icon"></i>회원가입</div>
</section>


<section class="right_menu list">
	<form name="member" method="post" enctype="multipart/form-data" action="./member_pro.php" onSubmit="return joinCheck('Join')"><input type="hidden" name="PHPSESSID" value="185dbf63c0becc7ce2f7936c9f78e021" />
	<input type="hidden" name="id_chk" id="id_chk" value="N" />
	<input type="hidden" name="mode" id="mode" value="join" />
	<table>
		<colgroup>
			<col width="30%"><col width="70%">
		</colgroup>
        <tbody>
        	<tr>
            	<th>이메일</th>
                <td>
                	<input type="text" name="email1" type="text" style="width:120px;" autofocus required> @ <input type="text" name="email2" style="width:150px;" required/>
                    <select name="email3">
						<option value="">직접입력</option>
						<option value="naver.com">네이버</option>
<option value="nate.com">네이트</option>
<option value="hanmail.net">한메일</option>
<option value="gmail.com">지메일</option>
<option value="yahoo.com">야후</option>
<option value="dreamwiz.com">드림위즈</option>
<option value="empal.com">엠파스</option>
<option value="freechal.com">프리첼</option>
<option value="hanafos.com">하나포스</option>
<option value="hanmir.com">한미르</option>
<option value="hitel.net">하이텔</option>
<option value="hotmail.com">핫메일</option>
<option value="korea.com">코리아닷컴</option>
<option value="lycos.co.kr">라이코스</option>
<option value="netian.com">네띠앙</option>
<option value="paran.com">파란</option>
<option value="yahoo.co.kr">야후코리아</option>
<option value="chol.com.com">천리안</option>
                    </select><br>
                    <span style="line-height: 15pt !important;" class="font small"><i style="margin:0;" class="check circle outline icon"></i>실제 사용중인 메일을 입력해 주세요.</span>
                </td>
            </tr>
            <tr>
            	<th>비밀번호</th>
            	<td>
            		<input type="password" name="passwd" id="pwd" style="width:120px;" value="" required/>
            		<span class="font small"><i style="margin:0;" class="check circle outline icon"></i>비밀번호를 최소 6자리 이상 입력해 주세요.</span>
            	</td>
            </tr>
            <tr>
            	<th>비밀번호확인</th>
            	<td>
            		<input type="password" name="repasswd" style="width:120px;" value="" required />
            		<span class="font small"><i style="margin:0;" class="check circle outline icon"></i>위에 입력한 비밀번호와 동일하게 입력해 주세요.</span>
            	</td>
            </tr>
            <tr>
            	<th>닉네임</th>
                <td>
                	<input type="text" name="userid" id="uid" style="width:120px;" value="" maxlength="12" required/>
                	<span class="font small"><i style="margin:0;" class="check circle outline icon"></i>중복된 닉네임인지 확인합니다.</span>
                </td>
            </tr>
            <tr>
            	<th>이름</th>
                <td>
                	<input type="text" name="name" id="name" style="width:120px;" value="" maxlength="10" /required>
                	<p>출금신청시 실명과 동일해야하므로 반드시 실명을 입력 해 주세요.</p>
                </td>
            </tr>
            <tr>
            	<th>프로필이미지등록</th>
                <td><input type="file" name="photo" id="photo" /> <p>115*115에 최적화되어 있습니다.</p></td>
            </tr>
           	<tr>
            	<th>휴대폰번호</th>
                <td>
                	<div class="no-request">
                		<input type="hidden" name="hp_yn" value="N">
                		<input type="hidden" name="hp_auth" value="N">
						<select name="hp1" required>
							<option value=""> 선택</option>
							<option value="010">010</option>
<option value="011">011</option>
<option value="016">016</option>
<option value="017">017</option>
<option value="018">018</option>
<option value="019">019</option>
						</select>
						- <input type="text" name="hp2" style="width:60px;ime-mode:disabled" maxlength="4" required/> - <input type="text" name="hp3" style="width:60px;ime-mode:disabled" maxlength="4" required/>
						<div class="btn green request" style="padding: 5px 12px; font-size:9pt !important; line-height:10pt !important; margin:0;">인증 요청</div>
					</div>
					<div class="layer-request" style="display:none;">
						<input type="text" name="requestnum" style="font-size: 9pt !important; line-height: 12pt !important;width:200px; text-align:center;" placeholder="인증번호를 3분 이내에 입력해 주세요.">
						<div class="btn green req-check" style="padding: 5px 12px; font-size:9pt !important; line-height:10pt !important; margin:0;">인증번호 확인</div>
					</div>
                    <span class="font small"><i style="margin:0;" class="check circle outline icon"></i>주문 업데이트 정보 및 메시지 알림을 문자로 알려드립니다.</span> <span class="timer" style="display:none;">3:00</span>
                </td>
            </tr>
            <tr>
            	<th>이용약관</th>
                <td>
                	<div class="txt_box">
                		
                        <p>크레벅스 서비스이용약관</p>
                        
                        <p>제 1 장 총 칙</p>
                        
                        <p>&nbsp;</p>
                        
                        <p>제 1 조 (목적)</p>
                        
                        <p>이 이용약관(이하 '약관')은 크레벅스(이하 회사)과 이용 고객(이하 '회원')간에 회사가 제공하는 서비스의 가입조건 및 이용에 관한 제반 사항과 기타 필요한 사항을 구체적으로 규정함을 목적으로 합니다.</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 2 조 (이용약관의 효력 및 변경)</p>
                        
                        <p>(1) 본 약관은 크레벅스가 운영하는 사이트(<a href="http://crebugs.com">http://crebugs.com</a>)에서 온라인으로 공시함으로써 효력을 발생하며, 합리적인 사유가 발생할 경우 개정될 수 있습니다. 이용자의 권리 또는 의무 등 중요한 규정은 개정과 함께 공지 합니다.</p>
                        
                        <p>(2) 본 약관에 동의하는 것은 정기적으로 사이트를 방문하여 약관의 변경사항을 확인하는 것에 동의함을 의미합니다. 변경된 약관에 대한 정보를 알지 못해 발생하는 이용자의 피해는 회사에서 책임지지 않습니다. </p>
                        
                        <p>(3) 회원은 변경된 약관에 동의하지 않을 경우 회원 탈퇴(해지)를 요청할 수 있으며, 변경된 약관의 효력 발생일로부터 7일 이후에도 거부의사를 표시하지 아니하고 서비스를 계속 사용할 경우 약관의 변경 사항에 동의한 것으로 간주됩니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 3 조 (약관 외 준칙)</p>
                        
                        <p>(1) 이 약관은 회사가 제공하는 개별서비스에 관한 이용안내와 함께 적용합니다. </p>
                        
                        <p>(2) 이 약관에 명시되지 아니한 사항에 대해서는 관계법령 및 이용안내의 취지에 따라 적용할 수 있습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 4 조 (용어의 정의)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 이 약관에서 사용하는 용어의 정의는 다음과 같습니다. </p>
                        
                        <p>가.&nbsp;'이용고객'이라 함은 회원제서비스를 이용하는 이용자를 말합니다. </p>
                        
                        <p>나. '이용계약'이라 함은 서비스 이용과 관련하여 회사와 이용고객 간에 체결 하는 계약 말합니다. </p>
                        
                        <p>다. '이용자번호(ID)'라 함은 이용고객의 식별과 이용고객의 서비스 이용을 위하여 이용고객이 선정하고 회사가 부여하는 문자와 숫자의 조합을 말합니다.</p>
                        
                        <p>라. '비밀번호'라 함은 이용고객이 부여 받은 이용자번호와 일치된 이용고객 임을 확인하고 이용고객의 권익보호를 위하여 이용고객이 선정한 문자와 숫자의 조합을 말합니다.</p>
                        
                        <p>마. '해지'라 함은 회사 또는 회원이 이용계약을 해약하는 것을 말합니다.</p>
                        
                        <p>사. '구매자' 컨텐츠나 서비스 관련 권리 및 물품을 구매한 회원을 말합니다.</p>
                        
                        <p>아. '판매자' 컨텐츠나 서비스 관련 권리 및 물품을 판매한 회원을 말합니다.</p>
                        
                        <p>자. '직거래'라 함은 회사가 제공하는 서비스를 이용하지 않고 이메일, 연락처, 메신져 아이디 등 교환을 통한 개인간 거래를 통한 거래를 말합니다.</p>
                        
                        <p>차. '프로필'이라 함은 경력, 자기소개, 포트폴리오를 관리할 수 있는 란을 말합니다.</p>
                        
                        <p>&nbsp;</p>
                        
                        <p>(2) 이 약관에서 사용하는 용어의 정의는 제1항에서 정하는 것을 제외하고는 관계법령 및 이용안내에서 정하는 바에 의합니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 2 장 이용계약 체결</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 5 조 (이용 계약의 성립)</p>
                        
                        <p>(1) 이용계약은 이용고객의 본 이용약관 내용에 대한 동의와 이용신청에 대하여 회사의 이용승낙으로 성립합니다. </p>
                        
                        <p>(2) 본 이용약관에 대한 동의는 이용신청 당시 해당 크레벅스 사이트의 '동의함' 버튼을 누름으로써 의사표시를 합니다. </p>
                        
                        <p>(3) 약관을 읽지 않음으로 발생할 수 있는 피해의 책임은 전적으로 회원에게 있습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 6 조 (서비스 이용 신청)</p>
                        
                        <p>(1) 회원으로 가입하여 본 서비스를 이용하고자 하는 고객은 회사에서 요청하는 제반정보 (이름, 이메일 주소, 연락처, 기타 부가정보 등)를 제공하여야 합니다. </p>
                        
                        <p>(2) 회사는 서비스 성격상 필요하다고 판단될 경우 당사는 이용고객의 실명을 요청할 수 있으며, 실명으로 등록하지 않은 회원에 대하여 서비스를 제한할 수 있고, 이용고객은 이에 관해서 권리를 주장할 수 없습니다. </p>
                        
                        <p>(3) 타인의 명의(이름 및 이메일 주소, 연락처)를 도용하여 이용신청을 한 회원의 모든 ID는 삭제되며, 관계법령에 따라 처벌을 받을 수 있습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 7 조 (개인정보의 보호 및 사용)</p>
                        
                        <p>회사는 관계법령이 정하는 바에 따라 이용자 등록정보를 포함한 이용자의 개인정보를 보호하기 위해 노력합니다. 이용자 개인정보의 보호 및 사용에 대해서는 관련법령 및 회사의 개인정보 취급방침이 적용됩니다. 단, 회사의 공식 사이트 이외의 웹에서 링크된 사이트에서는 회사의 개인정보 취급방침이 적용되지 않습니다. 또한 회사는 이용자의 귀책사유로 인해 노출된 정보에 대해서 일체의 책임을 지지 않습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 8 조 (이용 신청의 승낙과 제한)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회사는 제 6조의 규정에 의한 이용신청고객에 대하여 업무 수행상 또는 기술상 지장이 없는 경우에 원칙적으로 접수순서에 따라 서비스 이용을 승낙합니다. </p>
                        
                        <p>(2) 회사는 아래사항에 해당하는 경우에 대해서 승낙하지 않을 수 있습니다.</p>
                        
                        <p>- 실명이 아니거나 타인의 명의를 이용하여 신청한 경우 </p>
                        
                        <p>- 이용계약 신청서의 내용을 허위로 기재한 경우 </p>
                        
                        <p>- 사회의 안녕과 질서, 미풍양속을 저해할 목적으로 신청한 경우 </p>
                        
                        <p>- 부정한 용도로 본 서비스를 이용하고자 하는 경우 </p>
                        
                        <p>- 기타 규정한 제반사항을 위반하며 신청하는 경우 </p>
                        
                        <p>(3) 회사는 서비스 이용신청이 다음 각 호에 해당하는 경우에는 그 신청에 대하여 승낙 제한사유가 해소될 때까지 승낙을 유보할 수 있습니다.</p>
                        
                        <p>- 회사의 기술상 지장이 있는 경우 </p>
                        
                        <p>- 기타 회사의 귀책사유로 이용승낙이 곤란한 경우 </p>
                        
                        <p>(4) 회사는 이용신청고객이 관계법령에서 규정하는 미성년자일 경우에 이용안내에서 정하는 바에 따라 승낙을 보류할 수 있습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 9 조 (이용자ID 부여 및 변경 등)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회사는 이용고객에 대하여 약관에 정하는 바에 따라 이용자 ID를 부여합니다. </p>
                        
                        <p>(2) 이용자ID는 원칙적으로 변경이 불가하며 부득이한 사유로 인하여 변경 하고자 하는 경우에는 해당 ID를 해지하고 재가입해야 합니다. </p>
                        
                        <p>(3) 이용자ID는 다음 각 호에 해당하는 경우에는 이용고객 또는 회사의 요청으로 변경 할 수 있습니다. </p>
                        
                        <p>가. 이용자ID가 이용자의 전화번호 또는 주민등록번호 등으로 등록되어 사생활침해가 우려되는 경우 </p>
                        
                        <p>나. 타인에게 혐오감을 주거나 미풍양속에 어긋나는 경우 </p>
                        
                        <p>다. 기타 합리적인 사유가 있는 경우 </p>
                        
                        <p>(5) 서비스 이용자ID 및 비밀번호의 관리책임은 이용자에게 있습니다. 이를 소홀이 관리하여 발생하는 서비스 이용상의 손해 또는 제3자에 의한 부정이용 등에 대한 책임은 이용자에게 있으며 회사는 그에 대한 책임을 일절 지지 않습니다. </p>
                        
                        <p>(6) 기타 이용자 개인정보 관리 및 변경 등에 관한 사항은 이용안내에 정하는 바에 의합니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 3 장 계약 당사자의 의무</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 10 조 (회사의 의무)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회사는 이용고객이 희망한 서비스 제공 개시일에 특별한 사정이 없는 한 서비스를 이용할 수 있도록 하여야 합니다. </p>
                        
                        <p>(2) 회사는 계속적이고 안정적인 서비스의 제공을 위하여 설비에 장애가 생기거나 멸실된 때에는 부득이한 사유가 없는 한 지체없이 이를 수리 또는 복구합니다. </p>
                        
                        <p>(3) 회사는 개인정보 보호를 위해 보안시스템을 구축하며 개인정보 취급방침을 공시하고 준수합니다. </p>
                        
                        <p>(4) 회사는 이용고객으로부터 제기되는 의견이나 불만이 정당하다고 객관적으로 인정될 경우에는 적절한 절차를 거쳐 즉시 처리하여야 합니다. </p>
                        
                        <p>다만, 즉시 처리가 곤란한 경우는 이용자에게 그 사유와 처리일정을 통보하여야 합니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 11 조 (이용자의 의무)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 이용자는 회원가입 신청 또는 회원정보 변경 시 모든 사항을 사실과 실명(회사의 요청시)에 근거하여 작성하여야 하며, 허위 또는 타인의 정보를 등록할 경우 일체의 권리를 주장할 수 없습니다. </p>
                        
                        <p>(2) 회원은 본 약관에서 규정하는 사항과 기타 회사가 정한 제반 규정, 공지사항 등 회사가 공지하는 사항 및 관계법령을 준수하여야 하며, 기타 회사의 업무에 방해가 되는 행위, 회사의 명예를 손상시키는 행위로 회사가 피해를 입는 경우 회사가 회원에 손해배상을 청구할 수 있습니다.</p>
                        
                        <p>(3) 회원은 연락처, 이메일 주소 등 이용계약사항이 변경된 경우에 해당 절차를 거쳐 이를 회사에 즉시 알려야 합니다.</p>
                        
                        <p>(4) 회사가 관계법령 및 '개인정보 취급방침'에 의거하여 그 책임을 지는 경우를 제외하고 회원에게 부여된 ID의 비밀번호 관리소홀, 부정사용에 의하여 발생하는 모든 결과에 대한 책임은 회원에게 있습니다. </p>
                        
                        <p>(5) 회원은 회사의 사전 승낙 없이 서비스를 이용하여 영업활동을 할 수 없으며, 그 영업활동의 결과에 대해 회사는 책임을 지지 않습니다. 또한 회원은 이와 같은 영업활동으로 회사가 손해를 입은 경우, 회원은 회사에 대해 손해배상의무를 지며, 회사는 해당 회원에 대해 서비스 이용제한 및 적법한 절차를 거쳐 손해배상 등을 청구할 수 있습니다. </p>
                        
                        <p>(6) 회원은 회사의 명시적 동의가 없는 한 서비스의 이용권한, 기타 이용계약상의 지위를 타인에게 양도, 증여할 수 없으며 이를 담보로 제공할 수 없습니다. </p>
                        
                        <p>(7) 회원은 회사 및 제 3자의 지적 재산권을 침해해서는 안됩니다. </p>
                        
                        <p>(8) 회원이 직거래 시도를 할 경우 메시지 또는 메일로 경고를 하게 되며, 경고 이후에도 직거래로 간주되는 메세지 전송 및 유도를 할 경우 이용이 제한 될 수 있습니다.</p>
                        
                        <p>(9) 회원이&nbsp;11조에 해당하는 내용으로&nbsp;이용정지 및 탈퇴처리가 될 경우 수익금은 즉시 소멸되며, 사유에 따라 60일의 보류 기간 후 기타 문제가 없을 경우 확인된&nbsp;본인 계좌로 출금할 수 있습니다.&nbsp;</p>
                        
                        <p>(10) 판매자는 판매등록과 동시에 해당 상품을 판매할 의무가 있으며, 등록한 내용의 관련법규 위반등 모든 책임은 판매자가 감수해야 됩니다. 이에 대해 회사는 책임지지 않습니다.</p>
                        
                        <p>(11) 판매자는 주문에 대해 최종결과물을 전달할 때에만 구매자에게 완료요청을 해야하며, 계속적으로 최종결과물을 전달하기 전에 완료요청을 할 경우 이용이 제한될 수 있습니다.</p>
                        
                        <p>(12) 의도적으로 연락처 교환을 위해 결제 후 주문에 대한&nbsp;취소를 할 경우 즉시 이용정지 처리 되며, 모든 수익금은 즉시 소멸 됩니다.</p>
                        
                        <p>(13) 욕설, 성인물, 비난, 악용, 저작권 위반, 광고성, 스팸, 폭력, 사기 등의 적절하지 못한 행위는 제제 대상이며, 사용계정 탈퇴처리 및 IP접속 차단이 될 수 있습니다.</p>
                        
                        <p>(14) 회원은 다음 각 호에 해당하는 행위를 하여서는 안되며, 해당 행위를 하는 경우에 회사는 회원의 서비스 이용제한 및&nbsp;법적 조치를 포함한 제재를 가할 수 있습니다. </p>
                        
                        <p>&nbsp;</p>
                        
                        <p>- 회원가입 신청 또는 회원정보 변경 시 허위내용을 등록하는 행위 </p>
                        
                        <p>- 타인의 ID, 비밀번호, 연락처를 도용하는 행위 </p>
                        
                        <p>- 이용자 ID를 타인과 거래하는 행위 </p>
                        
                        <p>- 회사의 운영진, 직원 또는 관계자를 사칭하는 행위 </p>
                        
                        <p>- 회사로부터 특별한 권리를 부여받지 않고 회사의 클라이언트 프로그램을 변경하거나, 회사의 서버를 해킹하거나, 웹사이트 또는 게시된 정보의 일부분 또는 전체를 임의로 변경하는 행위 </p>
                        
                        <p>- 서비스에 위해를 가하거나 고의로 방해하는 행위 </p>
                        
                        <p>- 본 서비스를 통해 얻은 정보를 회사의 사전 승낙 없이 서비스 이용 외의 목적으로 복제하거나, 이를 출판 및 방송 등에 사용하거나, 제 3자에게 제공하는 행위 </p>
                        
                        <p>- 공공질서 및 미풍양속에 위반되는 저속, 음란한 내용의 정보, 문장, 도형, 음향, 동영상을 전송, 게시, 전자우편 또는 기타의 방법으로 타인에게 유포하는 행위 </p>
                        
                        <p>- 모욕적이거나 개인신상에 대한 내용이어서 타인의 명예나 프라이버시를 침해할 수 있는 내용을 전송, 게시, 전자우편 또는 기타의 방법으로 타인에게 유포하는 행위</p>
                        
                        <p>- 판매자의 경우 회원간 거래시 최종작업물이 아님에도 완료요청을 하는 행위</p>
                        
                        <p>- 다른 이용자를 희롱 또는 위협하거나, 특정 이용자에게 지속적으로 고통 또는 불편을 주는 행위 </p>
                        
                        <p>- 회사의 승인을 받지 않고 다른 사용자의 개인정보를 수집 또는 저장하는 행위 </p>
                        
                        <p>- 범죄와 결부된다고 객관적으로 판단되는 행위 </p>
                        
                        <p>- 본 약관을 포함하여 기타 회사가 정한 제반 규정 또는 이용 조건을 위반하는 행위 </p>
                        
                        <p>- 기타 관계법령에 위배되는 행위 </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 4 장 서비스의 이용</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 12 조 (서비스 이용 시간)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 서비스 이용은 회사의 업무상 또는 기술상 특별한 지장이 없는 한 연중무휴, 1일 24시간 운영을 원칙으로 합니다. </p>
                        
                        <p>단, 회사는 시스템 정기점검, 증설 및 교체를 위해 회사가 정한 날이나 시간에 서비스를 일시중단할 수 있으며, 예정되어 있는 작업으로 인한 서비스 일시중단은 사이트를 통해 사전에 공지합니다. </p>
                        
                        <p>(2) 회사는 긴급한 시스템 점검, 증설 및 교체 등 부득이한 사유로 인하여 예고없이 일시적으로 서비스를 중단할 수 있으며, 새로운 서비스로의 교체 등 회사가 적절하다고 판단하는 사유에 의하여 현재 제공되는 서비스를 완전히 중단할 수 있습니다. </p>
                        
                        <p>(3) 회사는 국가비상사태, 정전, 서비스 설비의 장애 또는 서비스 이용의 폭주 등으로 정상적인 서비스 제공이 불가능할 경우, 서비스의 전부 또는 일부를 제한하거나 중지할 수 있습니다. 다만 이 경우 그 사유 및 기간 등을 회원에게 사전 또는 사후에 공지합니다. </p>
                        
                        <p>(4) 회사는 회사가 통제할 수 없는 사유로 인한 서비스중단의 경우(시스템관리자의 고의, 과실없는 디스크장애, 시스템다운 등)에 사전통지가 불가능하며 타인(기간통신사업자 등)의 고의, 과실로 인한 시스템중단 등의 경우에는 통지하지 않습니다. </p>
                        
                        <p>(5) 회사는 서비스를 특정범위로 분할하여 각 범위별로 이용가능시간을 별도로 지정할 수 있습니다. 다만 이 경우 그 내용을 공지합니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 13 조 (이용자ID 관리)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 이용자ID와 비밀번호에 관한 모든 관리책임은 회원에게 있습니다. </p>
                        
                        <p>(2) 회사는 이용자 ID에 의하여 제반 이용자 관리업무를 수행 하므로 회원이 이용자 ID를 변경하고자 하는 경우 회사가 인정할 만한 사유가 없는 한 이용자 ID의 변경을 제한할 수 있습니다. </p>
                        
                        <p>(3) 이용고객이 등록한 이용자 ID 및 비밀번호에 의하여 발생되는 사용상의 과실 또는 제 3자에 의한 부정사용 등에 대한 모든 책임은 해당 이용고객에게 있습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 14 조 (게시물의 관리)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 판매 글의 등록요청 시 홈페이지에 노출될 내용 및 이미지가&nbsp;수정이 필요하다고 판단될 경우 관리자가 내용 및 이미지를 수정하여 등록 할 수 있습니다.</p>
                        
                        <p>(2) 회사는 다음 각 호에 해당하는 게시물이나 자료를 사전통지 없이 삭제하거나 이동 또는 등록 거부를 할 수 있습니다. </p>
                        
                        <p>- 다른 회원 또는 제 3자에게 심한 모욕을 주거나 명예를 손상시키는 내용인 경우 </p>
                        
                        <p>- 공공질서 및 미풍양속에 위반되는 내용을 유포하거나 링크시키는 경우 </p>
                        
                        <p>- 불법복제 또는 해킹을 조장하는 내용인 경우 </p>
                        
                        <p>- 영리를 목적으로 하는 광고일 경우 </p>
                        
                        <p>- 범죄와 결부된다고 객관적으로 인정되는 내용일 경우 </p>
                        
                        <p>- 다른 이용자 또는 제 3자의 저작권 등 기타 권리를 침해하는 내용인 경우 </p>
                        
                        <p>- 회사에서 규정한 게시물 원칙에 어긋나거나, 게시판 성격에 부합하지 않는 경우 </p>
                        
                        <p>- 기타 관계법령에 위배된다고 판단되는 경우 </p>
                        
                        <p>(3) 프로필 인증마크는 성명과 인증관련서류와의 일치시 부여되므로 정확하지 않을 수&nbsp;있으며,&nbsp;이에 대한 문제의&nbsp;피해 보상은 하지 않습니다.</p>
                        
                        <p>(4) 회원간 주고 받는 메세지는 직거래 피해 방지 및&nbsp;안전한 거래를 위하여 관리자의 필터링이 이루어질 수 있습니다.</p>
                        
                        <p>&nbsp;</p>
                        
                        <p>제15조 (게시물의 이용)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회원이 서비스에 게시물을 게재하는 경우, 회원은 회사가 게시물을 복제/전송/데이터베이스 제작 등의 형태로 이용 및 제휴사이트와 언론기관 등에 제공하는 것, </p>
                        
                        <p>서비스 내에서 다른 회원이 본인의 게시물 등을 스크랩 기능 등을 이용하여 복제 또는 전송 등의 형태로 이용하는 것을 동의한 것으로 봅니다. </p>
                        
                        <p>(2) 회사는 제1항의 규정에 의해 회원의 게시물을 언론기관 등에 제공할 경우, 이용자의 동의없이 이용자ID 이외 별도의 회원정보는 제공하지 않습니다. </p>
                        
                        <p>(3) 회사는 사이트 이용, 전송된 파일과 컨텐츠 사용시에 발생한 어떠한 피해에도 책임이 없습니다.</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 16 조 (게시물에 대한 저작권)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회원 또는 회사가 서비스 내에 게시한 게시물은 저작권법에 의한 보호를 받으며, 게시물의 저작권은 해당 게시물의 작성자에게 귀속합니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(2) 회원은 다음 각 호에 해당하는 범위 내에서 회원이 등록한 게시물을 회사가 무상으로 사용하는 것을 허락합니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>가. 서비스 내에서 게시물의 복제, 전송, 전시, 배포 및 이를 위하여 게시물 크기를 변화하거나 단순화하는 등의 방식으로 수정하는 것 </p>
                        
                        <p>나. 회원이 게시물을 등록할 당시 또는 회원정보 상의 선택사항(스크랩, 담기, 검색 허용 등)을 통하여 추가로 허락한 범위 내에서의 게시물의 복제, 전송, 전시, 배포. 그 범위는 회사가 운영하는 관련 사이트의 서비스 및 제휴사가 운영하는 서비스를 포함할 수 있습니다. </p>
                        
                        <p>다. 게시물 검색 서비스 등 향상된 서비스 제공을 위하여 관련 제휴사에게 필요한 자료 (게시물 제목 및 내용, 게시자ID, 게시일, 조회수 등)를 복제, 전송하는 것. </p>
                        
                        <p>단 이 경우 제공한 자료는 회사가 지정한 목적 이외에 사용되지 않으며 회원의 ID를 제외한 개인정보는 제공되지 않습니다.</p>
                        
                        <p>&nbsp;</p>
                        
                        <p>(3) 회원이 등록한 게시물의 내용은 회사가 운영하는 블로그나 사이트에 올려질 수 있으며 홍보를 위해 쓰일 수 있습니다. 회원이 등록한 게시물에 저작권에 문제가 있을 경우 책임은 게시물을 등록한 회원에게 있습니다.</p>
                        
                        <p>&nbsp;</p>
                        
                        <p>(4) 판매자와 구매자간에 주고 받는 파일은 안전한 거래를 위해 관리자가 확인할 수 있습니다.</p>
                        
                        <p>&nbsp;</p>
                        
                        <p>제 17 조 (수익금, 정산금)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>가. 서비스로 인해 발생된 수익은 회사가 별도로 정하는 수익배분 기준에 의해서 판매회원에게 분배됩니다.</p>
                        
                        <p>나. 구체적인 수익배분 방법에 관해서는 회사가 별도로 지정한 방법에 따릅니다.</p>
                        
                        <p>다. 회원탈퇴를 했을 경우 또는 제 11조에 해당되는 사유로 서비스 이용이 정지된 경우 서비스에서 발생되는 수익금은 바로 영구 소멸 되며 ID 삭제 및 형사 고발 등 기타 조치를 취할 수 있습니다.</p>
                        
                        <p>라. 회원은 수익금의 양도, 대여 등 어떠한 처분행위도 할 수 없습니다. </p>
                        
                        <p>마. 회사는 서비스의 효율적인 이용 및 운영을 위해 사전 공지 후 수익금의 적립 방법 및 출금 방법을 조정할 수 있으며, 수익금은 회사가 정한 금액 이상이 되었을때 회원의 계좌로 출금 신청 할 수 있습니다. </p>
                        
                        <p>바. 결제후 잔고에 있는 충전 금액을 환불을 받고자 할때는 고객센터로 문의할 수 있고, 충전 금액의 일부를 사용했을 경우 환불은 불가능 합니다.</p>
                        
                        <p>사. 판매자가 수익금을 인출한 후 구매자가 받은 작업물에 문제가 있을 경우 회사는 판매자의 계좌로 입금된 금액을 다시 회사계좌로 입금 요청 할 수 있습니다.</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 18 조 (정보의 제공)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회사는 회원에게 서비스 이용에 필요가 있다고 인정되는 각종 정보에 대해서 전자우편이나 서신우편 등의 방법으로 회원에게 제공할 수 있습니다. </p>
                        
                        <p>(2) 회사는 서비스 개선 및 회원 대상의 서비스 소개 등의 목적으로 회원의 동의 하에 추가적인 개인 정보를 요구할 수 있습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 19 조 (광고게재 및 광고주와의 거래)</p>
                        
                        <p>(1) 회사가 회원에게 서비스를 제공할 수 있는 서비스 투자기반의 일부는 판매자의 판매수수료, 광고게재를 통한 수익으로부터 나옵니다. 회원은 서비스 이용시 노출되는 광고게재에 대해 동의합니다. </p>
                        
                        <p>(2)회사는 서비스상에 게재되어 있거나 본 서비스를 통한 광고주의 판촉활동에 회원이 참여하거나 교신 또는 거래를 함으로써 발생하는 손실과 손해에 대해 책임을 지지 않습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 5 장 계약 해지 및 이용 제한</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 20 조 (계약 변경 및 해지)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회원은 언제든지 회원정보수정 메뉴 등을 통하여 이용계약 해지 신청을 할 수 있으며, 회사는 관련법 등이 정하는 바에 따라 이를 즉시 처리하여야 합니다. </p>
                        
                        <p>(2) 회원이 계약을 해지할 경우, 관련법 및 개인정보취급방침에 따라 회사가 회원정보를 보유하는 경우를 제외하고는 해지 즉시 회원의 모든 개인정보는 소멸됩니다. </p>
                        
                        <p>(3) 회원이 계약을 해지하는 경우, 회원이 작성한 게시물 일체는 삭제되지 않으니 계약 해지 후 게시를 원하지 않으시면 사전에 삭제 후 탈퇴하시기 바랍니다. </p>
                        
                        <p>계약을 해지한 회원의 삭제되지 않은 게시물에 대한 저작권은 전적으로 회사에 위임됩니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 21 조 (서비스 이용제한)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회사는 회원이 서비스 이용내용에 있어서 본 약관 제 11조 내용을 위반하거나, 다음 각 호에 해당하는 경우 서비스 이용을 제한할 수 있습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>- 미풍양속을 저해하는 비속한 ID 및 별명 사용 </p>
                        
                        
                        <p>- 타 이용자에게 심한 모욕을 주거나, 서비스 이용을 방해한 경우 </p>
                        
                        <p>- 기타 정상적인 서비스 운영에 방해가 될 경우 </p>
                        
                        <p>- 정보통신 윤리위원회 등 관련 공공기관의 시정 요구가 있는 경우 </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>가. 상용소프트웨어나 크랙파일을 올린 경우 </p>
                        
                        <p>나 정보통신윤리 위원회의 심의 세칙 제 7조에 어긋나는 음란물을 게재한 경우 </p>
                        
                        <p>다. 반국가적 행위의 수행을 목적으로 하는 내용을 포함한 경우 </p>
                        
                        <p>라. 저작권이 있는 글을 무단 복제하거나 mp3를 홈계정에 올린 경우 </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(2) 상기 이용제한 규정에 따라 서비스를 이용하는 회원에게 서비스 이용에 대하여 별도 공지 없이 서비스 이용의 일시정지, 초기화, 이용계약 해지 등을 불량이용자 처리규정에 따라 취할 수 있습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 6 장 손해배상 및 기타사항</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 22 조 (손해배상)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회사는 서비스에서 무료로 제공하는 서비스의 이용과 관련하여 개인정보 취급방침에서 정하는 내용에 해당하지 않는 사항에 대하여는 어떠한 손해도 책임을 지지 않습니다. </p>
                        
                        <p>(2) 본 회사와 관련없이 개인 또는 타 회사의 이득을 위한 메시지발송으로 인한 회사의 지출에 대해서는 손해배상을 청구 할 수 있습니다.</p>
                        
                        <p>(3)&nbsp;본 회사는 고객간의 중개시스템을 제공하기 때문에 거래의 결과물에 대해 책임을 지지 않습니다.</p>
                        
                        <p>&nbsp;</p>
                        
                        <p>&nbsp;</p>
                        
                        <p>제 23 조 (면책조항)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 회사는 천재지변, 전쟁 및 기타 이에 준하는 불가항력으로 인하여 서비스를 제공할 수 없는 경우에는 서비스 제공에 대한 책임이 면제됩니다. </p>
                        
                        <p>(2) 회사는 기간통신 사업자가 전기통신 서비스를 중지하거나 정상적으로 제공하지 아니하여 손해가 발생한 경우 책임이 면제됩니다. </p>
                        
                        <p>(3) 회사는 서비스용 설비의 보수, 교체, 정기점검, 공사 등 부득이한 사유로 발생한 손해에 대한 책임이 면제됩니다. </p>
                        
                        <p>(4) 회사는 회원의 귀책사유로 인한 서비스 이용의 장애 또는 손해에 대하여 책임을 지지 않습니다.</p>
                        
                        <p>(5) 회사는 이용자의 컴퓨터 오류에 의해 손해가 발생한 경우, 또는 회원이 신상정보 및 전자우편 주소를 부실하게 기재하여 손해가 발생한 경우 책임을 지지 않습니다. </p>
                        
                        <p>(6) 회사는 회원이 서비스를 이용하여 기대하는 수익을 얻지 못하거나 상실한 것에 대하여 책임을 지지 않습니다. </p>
                        
                        <p>(7) 회사는 회원이 서비스를 이용하면서 얻은 자료로 인한 손해에 대하여 책임을 지지 않습니다. </p>
                        
                        <p>또한 회사는 회원이 서비스를 이용하며 타 회원으로 인해 입게 되는 정신적 피해에 대하여 보상할 책임을 지지 않습니다.</p>
                        
                        <p>(8) 회사는 회원이 서비스에 게재한 각종 정보, 자료, 사실의 신뢰도, 정확성 등 내용에 대하여 책임을 지지 않습니다. </p>
                        
                        <p>(9) 회사는 이용자 상호간 및 이용자와 제 3자 상호 간에 서비스를 매개로 물품거래 등의 거래를 통해 발생한 분쟁에 대해 개입할 의무가 없으며, 이로 인한 손해를 배상할 책임도 없습니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제 24 조 (재판권 및 준거법)</p>
                        
                        <p>&nbsp; </p>
                        
                        <p>(1) 이 약관에 명시되지 않은 사항은 전기통신사업법 등 관계법령과 상관습에 따릅니다. </p>
                        
                        <p>(2) 서비스 이용으로 발생한 분쟁에 대해 소송이 제기되는 경우 회사의 본사 소재지를 관할하는 법원을 관할 법원으로 합니다. </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>부칙 </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>제1조 (적용일자) </p>
                        
                        <p>&nbsp; </p>
                        
                        <p>이 정책은 2013년 1월 01일부터 적용됩니다.</p>                    </div>
                    <p><label for="chk1">이용약관에 동의하시겠습니까?</label> <input type="checkbox" id="chk1" name="check1" required> </p> 
                </td>
            </tr>
            <tr>
            	<th>개인정보 취급방침</th>
                <td>
                	<div class="txt_box">
                		
                        <p>&nbsp;크레벅스(이하 “당사”라 한다.)는 회원님들의 개인정보를 매우 중요하게 생각하며 다음과 같은 개인정보보호정책을 가지고 있습니다. 이 개인정보보호정책은 개인정보보호와 관련한 법률 또는 지침의 변경, 회사 정책의 변화에 따라 달라질 수 있으니 회원님께서는 당사 사이트 방문시 수시로 확인하시기 바랍니다.</p>
                        <p>&nbsp;개인정보란 생존하는 개인에 관한 정보로서 당해 정보에 포함되어 있는 성명, 주소, 전화번호등에 의하여 당해 개인을 식별할 수 있는 정보(당해 정보만으로는 특정 개인을 식별할 수 없더라도 다른 정보와 용이하게 결합하여 식별할 수 있는 것을 포함합니다)를 말합니다</p>
                        <p><br>&nbsp;1. 개인정보 수집에 대한 동의<br>&nbsp;크레벅스은 서비스 이용을 위한 회원가입시 이용약관의 내용에 대하여 동의하는 의사표시를 ‘동의후 가입’ 버튼을 누르는 절차를 마련하고 있으며 같은 화면에서 개인정보보호정책 또한 확인하실수 있습니다. 동의의 의사표시가 있는 경우 개인정보의 수집에 동의한 것으로 봅니다.<br>&nbsp;또한 크레벅스은 개인정보보호정책을 홈페이지 첫화면에 공개함으로써 귀하께서 언제나 용이하게 보실 수 있도록 조치하고 있습니다.</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;2. 개인정보 수집의 목적 및 이용<br>&nbsp;가. 크레벅스가 개인정보를 수집하는 목적은 회원의 신분과 서비스 이용의사를 확인하여 최적화되고 맞춤화된 서비스를 제공하기 위함입니다. 크레벅스은 회원께서 재화 및 서비스 상품을 주문, 결제, 배송하고 기타 회원님들을 위한 각종 서비스를 제공하기 위해 필요한 최소한의 정보를 수집하고 있습니다. <br>&nbsp;나. 크레벅스은 개인정보의 기본 수집목적 이외에 다른 용도로 이를 이용하거나 회원의 동의없이 제3자에게 이를 제공하지 않습니다. <br>&nbsp;다. 크레벅스은 다음과 같은 목적으로 개인정보를 수집하며 이용합니다.<br>&nbsp;1) 이름, 주민번호, 아이디, 비밀번호 : 당사가 이용하는 서비스 이용에 따른 본인확인<br>&nbsp;2) 이메일주소, 전화번호 : 회원간 거래의 원활한 진행, 본인의사확인, 불만처리, 새로운 정보와 고지사항의 안내<br>&nbsp;3) 결제정보 : 대금결제서비스의 제공<br>&nbsp;4) 기타 : 회원의 특성에 맞는 서비스 제공을 위한 자료<br>&nbsp;<br>&nbsp;3. 개인 정보의 수집항목 및 방법<br>&nbsp;가. 크레벅스은 최초 회원가입시 서비스 제공을 원활하게 하기 위해 필요한 최소한의 정보만을 받고 있으며 당사가 제공하는 서비스 이용에 따른 결제관련정보, 배송관련정보, 환불관련정보를 추가로 수집할 수 있습니다. <br>&nbsp;1)회원가입시 수집하는 개인정보<br>&nbsp;a. 필수항목 : 이름, ID, 비밀번호, 주소, 주민등록번호, 전자우편주소, 연락전화번호<br>&nbsp;b. 선택항목 : 이동전화번호<br>&nbsp;<br>&nbsp;2) 추가수집 개인정보<br>&nbsp;a. 결제관련정보 : 거래은행명, 계좌번호, 예금주<br>&nbsp;b. 배송관련정보 : 수취인 이름, 주소, 연락처<br>&nbsp;c. 환불관련정보 : 환불계좌 은행명, 계좌번호, 예금주</p>
                        <p>&nbsp;나. 크레벅스은 회원의 개인정보를 수집할 경우 반드시 회원의 동의를 얻어 수집하며 회원님의 기본적인권을 침해할 우려가 있는 인종, 출신지, 본적지, 사상, 정치적성향, 범죄기록, 건강상태 등의 정보는 회원의 동의 또는 법령의 규정에 의한 경우 이외에는 수집하지 않습니다.</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;4. 개인정보의 열람 및 정정<br>&nbsp;가. 회원은 언제든지 등록되어 있는 개인정보를 열람하거나 정정할 수 있습니다. <br>&nbsp;나. 개인정보 열람 및 정정을 하고자 할 경우에는 로그인후 홈페이지 상단의 ‘나의정보’에서 언제든지 열람, 정정할 수 있으며, 당사 고객센터 또는 개인정보관리담당자에게 서면, 전화, 또는 전자우편으로 연락하시면 즉각 조치합니다. <br>&nbsp;다. 회원이 개인정보 오류에 대한 정정을 요청한 경우 정정을 완료하기 전까지 해당 개인정보를 이용, 제공하지 않으며, 제3자에게 기제공된 정보에 대해서도 지체없이 통보하여 정정하도록 조치하고 수정된 정보는 수정 절차가 완료된 시점부터 바로 적용됩니다.</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;5. 개인정보 수집, 이용, 제공에 대한 동의 철회(회원탈퇴)<br>&nbsp;가. 회원가입 등을 통한 개인정보의 수집, 이용, 제공에 대하여 회원은 가입시 동의한 내용을 언제든지 철회할 수 있습니다. <br>&nbsp;나. 동의철회는 당사 사이트에서 언제든지 하실 수 있으며, 개인정보관리책임자에게 서면, 전화 또는 E-mail 등으로 연락하시면 즉시 개인정보 삭제등 필요한 조치를 합니다.<br>&nbsp;다. 당사는 개인정보의 수집에 대한 동의철회를 개인정보 수집시와 동등한 방법 및 절차로 행사할 수 있도록 필요한 조치를 취합니다.</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;6. 개인정보의 보유기간 및 이용기간<br>&nbsp;가. 크레벅스가 회원의 개인정보를 수집하는 경우 그 보유기간은 원칙적으로 회원가입후 구매서비스 이용약관 제9조에 의한 이용계약 종료시, 판매서비스이용약관 제13조에 의한 해지시까지며, 이용계약이 종료할 경우 당사는 회원의 개인정보를 즉시 파기하여 제3자에게 기제공된 정보에 대해서도 지체없이 파기하도록 조치합니다. 다만, 다음의 경우 각각 명시한 기간동안 개인정보를 보유합니다. <br>&nbsp;1) 상법 등 법령의 규정에 의하여 보존할 필요성이 있는 경우 법령에서 규정한 보존기간동안 거래내역과 최소한의 기본정보를 보유<br>&nbsp;2) 보유기간을 미리 공지하고 그 보유기간이 경과하지 아니한 경우와 개별적으로 회원의 동의를 받을 경우에는 약정한 기간동안 보유<br>&nbsp; 나. 회원의 동의를 받아 보유하고 있는 개인정보에 대한 당해회원의 열람요구가 있을 경우 당사는 지체없이 이를 열람, 확인할 수 있도록 조치합니다.</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;7. 개인정보의 제공 및 보유<br>&nbsp;가. 크레벅스은 회원의 개인정보를 위에서 고지한 개인정보 수집의 목적 및 이용 범위내에서 사용하며 원칙적으로 제3자에게 제공하지 않습니다. <br>&nbsp;나. 다만 다음의 경우에는 합당한 절차를 통한 회원의 동의를 얻어 개인정보를 제공 또는 이용할 수 있습니다. <br>&nbsp;1)제휴관계 :&nbsp; 회원에게 보다 나은 서비스 제공을 위하여 당사는 회원의 개인정보를 제휴사에 제공하거나 제휴사와 공유할 수 있습니다. 이 경우 사전에 회원에게 제휴사, 제공 및 공유되는 개인정보의 항목, 개인정보 제공 및 공유의 목적, 제공기간, 개인정보보호방안등에 대해서 개별적으로 고지하는 절차를 걸쳐, 회원의 동의가 없는 경우에는 이를 제공 또는 공유하지 않으며 제휴관계의 변화 또는 종결될 경우에도 고지합니다. 또한 제휴관계가 종결될 경우 제공된 개인정보에 대해서는 회원님의 동의가 없는 경우 지체없이 파기하도록 조치하며 일단 개인정보 제공에 동의하더라도 언제든지 그 동의를 철회할 수 있습니다. <br>&nbsp;나. 다음은 예외로 합니다. <br>&nbsp;1) 관련법령(금융실명거래및비밀보장에관한법률, 신용정보의이용및보호에관한법률, 전기통신기본법, 전기통신사업법, 지방세법, 소비자보호법, 전자상거래등에서의소비자보호에관한법률, 표시광고의공정화에관한법률, 형사소송법 등) 에 특별한 규정이 있는 경우<br>&nbsp;2) 서비스 제공에 따른 요금 정산을 위하여 필요한 경우<br>&nbsp;3) 당사가 제공하는 서비스를 통하여 거래가 성사된 경우 거래당사자간의 원활한 의사소통과 거래, 배송을 위하여 관련된 정보를 필요한 범위내에서 거래당사자에게 제공하는 경우<br>&nbsp;4) 학술연구, 통계목적, 시장조사를 위하여 특정개인을 식별할 수 없는 형태로 제공되는 경우</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;8. 쿠키에 의한 개인정보 수집<br>&nbsp;크레벅스은 귀하에 대한 정보를 저장하고 수시로 찾아내는 쿠키를 사용합니다. 쿠키는 웹사이트가 귀하의 컴퓨터 브라우저(익스플로러, 네스케이프등)로 전송하는 소량의 정보입니다. 쿠키에 관하여 본 웹사이트는 귀하에게 개인화되고 맞춤화된 서비스를 제공하기 위해 쿠키를 사용하고 있습니다. 쿠키는 귀하의 컴퓨터는 식별하지만 귀하를 개인적으로 식별하지는 않습니다. 이용자는 본 사이트에서 보내는 쿠키를 브라우저의 설정으로 거부할 수 있습니다. 그럴 경우 크레벅스에서 제공하는 서비스의 일부를 받을 수 없게 됩니다.<br>&nbsp;<br>&nbsp;9. 링크 사이트에 대한 책임 한계<br>&nbsp;크레벅스은 회원에게 다른 웹사이트 또는 자료에 대한 링크를 제공할 수 있습니다. 이 경우 당사는 외부사이트 및 자료에대한 아무런 통제권이 없으므로, 그로부터 제공받는 서비스나 자료의 유용성에 대해 책임을 지거나 보증할 수 없습니다. 당사가 포함하고 있는 링크를 통하여 다른 웹사이트로 갈 경우 해당 웹사이트의 개인보호정책은 당사와 무관하므로 회원은 새로 a방문한 웹사이트의 정책을 반드시 검토해 보시기 바랍니다. </p>
                        <p>&nbsp;</p>
                        <p>&nbsp;10. 개인정보보호를 위한 이용자의 주의사항<br>&nbsp;가. 크레벅스의 회원정보는 비밀번호에 의해 보호되고 있습니다. 회원은 비밀번호를 누구에게도 알려주어서는 안되며 본인의 유출에 따른 책임은 회원자신이 지게 되오니 각별히 유의해 주시기 바랍니다. 당사는 결코 전화나 전자우편으로 회원의 비밀번호를 묻거나 하지 않으며 이러한 일이 있을 경우에는 당사 고객센터 또는 개인정보관리책임자에게 신고하여 주시기 바랍니다. <br>&nbsp;나. 당사의 서비스를 이용한 후에는 반드시 회원의 계정을 종료하고 웹브라우저의 창을 닫아주시기 바랍니다. 이는 회원이 다른사람과 컴퓨터를 공유하여 사용하거나 인터넷카페, PC방, 도서관 등과 같은 공공장소에서 컴퓨터를 사용하는 경우 타인이 회원의 개인정보 및 통신내역을 볼 수 없도록 하기 위함입니다. <br>&nbsp;다. 회원은 불의의 사고를 예방하기 위하여 자신의 개인정보를 최신의 상태로 유지하는 것이 필요하며, 회원의 부정확한 정보 입력으로 발생하는 사고의 책임은 회원 자신에게 있음을 알립니다. 또한 타인의 정보를 도용하거나 허위의 정보를 입력할 경우 회원자격의 상실과 함께 형사고발의 대상이 될 수 있습니다. </p>
                        <p>&nbsp;</p>
                        <p>&nbsp;11. 개인정보보호를 위한 기술 및 관리적 대책<br>&nbsp;가. 기술적 대책<br>&nbsp;크레벅스은 귀하의 개인정보를 취급함에 있어 개인정보가 분실, 도난, 누출, 변조 또는 회손되지 않도록 안정성확보를 위하여 다음과 같은 기술적 대책을 강구할 수 있습니다. <br>&nbsp;1) 귀하의 개인정보는 비밀번호에 의해 보호되고 있습니다. <br>&nbsp;2) 크레벅스은 백신프로그램을 이용하여 컴퓨터바이러스에 의한 피해를 방지하기 위한 조치를 취하고 있습니다.백신프로그램은 주기적으로 업데이트되며 갑작스런 바이러스가 출현할 경우 백신이 나오는 즉시 이를 제공함으로써 개인정보가 침해되는 것을 방지하고 있습니다. <br>&nbsp;3) 해킹 등 외부에 침입에 대비하여 각 서버마다 침입차단시스템 및 취약점 분석 시스템 등을 이용하여 보안에 만전을 기하고 있습니다.</p>
                        <p>&nbsp;나. 관리적 대책<br>&nbsp;저희 크레벅스은 등록자의 개인정보보호의 중요성을 인식하고 있으며 이를 위해 개인정보 취급직원을 최소한으로 제한하고 있으며 개인정보관리책임자가 취급직원을 대상으로 교육을 주기적으로 실시하여 개인정보보호를 위해 최선을 다하고 있습니다. 또한 본 정책에 명시된 이행사항 및 관련직원의 준수여부를 정기적으로 점검하여 위반 내용이 있는 경우 이를 시정 또는 개선하고 기타 필요한 조치를 취하도록 하고 있습니다. </p>
                        <p>&nbsp;다. 크레벅스은 이용자 개인의 실수나 기본적인 인터넷의 위험성 때문에 일어나는 일들에 대해 책임을 지지 않습니다. 등록자 개개인이 본인의 개인정보를 보호하기 위해서 자신의 비밀번호를 적절하게 관리하고 여기에 대한 책임을 져야합니다.</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;12. 게시물<br>&nbsp;가. 크레벅스은 귀하의 게시물을 소중하게 생각하며 변조,훼손, 삭제되지 않도록 최선을 다하여 보호합니다. 그러나 다음의 경우는 사전동의 없이 삭제조치할 수 있습니다.<br>&nbsp;1) 내용이 불법적이거나 반사회적인 글<br>&nbsp;2) 내용이 허위, 과대, 광고성의 글<br>&nbsp;3) 욕설, 비방, 타인의 명예를 훼손하는 등의 내용이 포함된 글<br>&nbsp;4) 동의 없는 타인의 신상공개, 크레벅스의 저작권, 제3자의 저작권 등 권리를 침해하는 글<br>&nbsp;5) 게시판 주제와 다른 내용의 글<br>&nbsp;6) 기타 크레벅스의 운영목적에 적합하지 않은 글 등<br>&nbsp;나. 근본적으로 게시물에 관련된 제반 권리와 책임은 작성자 개인에게 있습니다. 또 게시물을 통해 자발적으로 공개된 정보는 보호받기 어려우므로 공개전에 심사숙고 하시기 바랍니다.</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;13. 의견수렴 및 불만처리<br>&nbsp;가. 크레벅스은 귀하의 의견을 소중하게 생각하며 귀하는 의문사항으로부터 언제나 성실한 답변을 받을 권리가 있습니다. <br>&nbsp;나. 저희 회사는 귀화와의 원활한 소통을 위해 고객센터를 운영하고 있으며 1:1 고객센터는 홈페이지에 접속하여 문의를 남기실 수 있습니다. </p>
                        <p>&nbsp;</p>
                        <p>&nbsp;14. 개인정보관리책임자<br>&nbsp;저희 크레벅스에서는 귀하가 좋은 정보를 안전하게 이용할 수 있도록 최선을 다하고 있습니다. 그러나 기술적인 보안조치를 했음에도 불구하고 해킹 등 기본적인 네트워크상의 위험성에 의해 발생하는 예기치 못한 사고로 인한 정보의 훼손 및 방문자가 작성한 게시물에 의한 각종 분쟁에 관해서 당사는 책임이 없습니다. 크레벅스에서는 개인정보관련 문의사항에 신속하고 성실하게 답변해드리고 있습니다. </p>
                        <p>&nbsp;<br>&nbsp;15. 고지의 의무<br>&nbsp;현 개인정보보호정책은 2013년 1월 10일에 제정되었으며 정부의 정책 또는 보안기술의 변경에 따라 내용의 추가, 삭제 및 수정이 있을 시에는 개정 최소 10일전부터 저희 웹사이트상의 공지사항란에 공지합니다. </p>
                        <p>&nbsp;개인정보보호정책 시행일자 : 2013년 1월 10일</p>
                        <p>&nbsp;</p>
                        <p>16. 개인정보에 관한 민원서비스</p>
                        <p>&nbsp;크레벅스은 고객의 개인정보를 보호하고 개인정보와 관련한 불만을 처리하기 위하여 아래와 같이&nbsp;관련 부서 및 개인정보관리책임자를 지정하고 있습니다.</p>
                        <p>&nbsp;- 고객서비스: 070-7534-9422</p>
                        <p>&nbsp;- 개인정보관리 책임자: 김범수</p>
                        <p>&nbsp;- 이메일: <a href="mailto:solkim@tendency.co.kr">solkim@tendency.co.kr</a></p>
                        <p>&nbsp;크레벅스 서비스를 이용하면서 발생하는 모든 개인정보보호 관련 민원을 개인정보관리책임자 혹은 담당고객센터로 신고하실 수 있습니다. 크레벅스은 이용자들의 신고사항에 신속하게 충분한 답변을 드릴 것입니다.</p>                    </div>
                    <p><label for="chk2">개인정보 취급방침에 동의하시겠습니까?</label> <input type="checkbox" id="chk2" name="check2" required> </p> 
               </td>
            </tr>
        </tbody>
	</table>
	<button type="submit" class="regButton float right"><i class="add user icon"></i>회원가입</button>
</form>
</section>

<script type="text/javascript">
	$(function(){

        min = 2;
        sec = 59;
        $timer = $(".timer");
        tim = -1;

		function timers() {
            if(sec < 0) {
                --min;
                sec = 59;
            }
            if(sec < 10)
                sec = "0" + sec;
            $timer.text(min + ":" +sec);
            if(min == 0 && sec == 0) {
            	// console.log('end');
                clearInterval(tim);
            }
            // console.log(min + ":" +sec);
            sec--;
		}

		// 휴대전화 인증번호 처리
		$('.btn.request').click(function(){
			if($('[name=hp1]').val() && $('[name=hp2]').val() && $('[name=hp3]').val()) {
				var request = $.ajax({
					type: "POST",
					url: "sms_proc.php",
					contentType: "application/x-www-form-urlencoded; charset=utf-8",
					data: 'mode=request&hp1='+$('[name=hp1]').val()+'&hp2='+$('[name=hp2]').val()+'&hp3='+$('[name=hp3]').val(),   
					dataType: "html"
				});
				request.done(function(msg) {
					//$('#result').html(msg);   
					// getdata = msg;
					$fontObj = $('.btn.request').parent().nextAll('.font').first();
					$fontObj.html(msg);
					$fontObj.removeClass('red');
					$fontObj.removeClass('green');

					$fontObj.addClass($fontObj.find('i').data('color'));

					if($fontObj.find('i').data('color') == 'green') {
						$('.layer-request').show();
						$('.no-request').hide();

						$timer.show();

				        min = 2;
				        sec = 59;
						tim = setInterval(timers, 1000);						
					} else {
						$('[name=hp_yn]').val('N');
					}
					// console.log($fontObj.find('i').data('color'));
					console.log('request done : '+msg);
				});   
				   
				request.fail(function(jqXHR, textStatus) {   
					alert('Error');
					console.log( "Request failed: " + textStatus );   
					// getdata = false;
				});
			} else {
				alert('입력란을 모두 채워주세요.');
			}
		});
		// 인증번호 확인 요청
		$('.req-check').click(function(){
			if($('[name=requestnum]').val()) {

				var request = $.ajax({
					type: "POST",
					url: "sms_proc.php",
					contentType: "application/x-www-form-urlencoded; charset=utf-8",
					data: 'mode=accept&hp1='+$('[name=hp1]').val()+'&hp2='+$('[name=hp2]').val()+'&hp3='+$('[name=hp3]').val()+'&requestnum='+$('[name=requestnum]').val(),   
					dataType: "html"
				});
				request.done(function(msg) {
					//$('#result').html(msg);   
					// getdata = msg;
					$fontObj = $('.btn.request').parent().nextAll('.font').first();
					$fontObj.html(msg);
					$fontObj.removeClass('red');
					$fontObj.removeClass('green');					

					$fontObj.addClass($fontObj.find('i').data('color'));

					if($fontObj.find('i').data('color') == 'green') {
						$('.btn.request').hide();
						$('.no-request').show();
						$('[name=hp_yn]').val('Y');
						$('.layer-request').hide();
						$timer.hide();
						clearInterval(tim);
						$('[name=hp1]').attr("disabled","disabled");
						$('[name=hp2]').attr("readonly","readonly");
						$('[name=hp3]').attr("readonly","readonly");
						$('[name=hp_auth]').val('Y');
					} else {
						$('[name=hp_yn]').val('N');
					}
					// console.log($fontObj.find('i').data('color'));
					console.log('request done : '+msg);
				});   
				   
				request.fail(function(jqXHR, textStatus) {   
					alert('Error');
					console.log( "Request failed: " + textStatus );   
					// getdata = false;
				});
			}
		});
		////////
		$('select[name=email3]').change(function(){
			var value = $(this).val();
			$('input[name=email2]').val(value);
			if(!value) {
				$('input[name=email2]').focus();
			} else {
				$('input[name=email2]').parent().parent().next().find('input').focus();
				// console.log($('input[name=email2]').parent().parent().next().find('input'));
			}
			$('input[name=email1]').keyup();
		});
		// 비밀번호
		$('input[name=passwd]').keyup(function(){
			var value = $(this).val();

			if(value.length > 5) {
				$(this).next('.font').removeClass('red');
				$(this).next('.font').addClass('green');
				$(this).next('.font').html('<i style="margin:0;" class="check circle icon"></i>사용 가능한 비밀번호 입니다.');
			} else if(/^[a-z0-9_-]{6,12}$/.test($("#pwd").val()) != true) {
				$(this).next('.font').removeClass('green');
				$(this).next('.font').addClass('red');
				$(this).next('.font').html('<i style="margin:0;" class="check circle outline icon"></i>비밀번호는 공백이나 특수문자, 한글을 제외한 6~12자로 입력해 주세요.');
			}
			 else {
				$(this).next('.font').removeClass('green');
				$(this).next('.font').addClass('red');
				$(this).next('.font').html('<i style="margin:0;" class="check circle outline icon"></i>비밀번호를 최소 6자리 이상 입력해 주세요.');
			}

			if($('input[name=repasswd]').val())
				$('input[name=repasswd]').keyup();
		});
		$('input[name=passwd]').keydown(function(){$(this).keyup();});
		$('input[name=passwd]').change(function(){$(this).keyup();});
		// 비밀번호 확인
		$('input[name=repasswd]').keyup(function(){
			var value = $(this).val();
			var org_value = $('input[name=passwd]').val();
			if(value)
				if(value == org_value) {
					$(this).next('.font').removeClass('red');
					$(this).next('.font').addClass('green');
					$(this).next('.font').html('<i style="margin:0;" class="check circle icon"></i>확인 되었습니다.');
				} else {
					$(this).next('.font').removeClass('green');
					$(this).next('.font').addClass('red');
					$(this).next('.font').html('<i style="margin:0;" class="check circle outline icon"></i>위에 입력한 비밀번호와 동일하게 입력해 주세요.');
				}
		});
		$('input[name=repasswd]').keydown(function(){$(this).keyup();});
		$('input[name=repasswd]').change(function(){$(this).keyup();});
		// 닉네임 체크
		$('input[name=userid]').keyup(function(){
			// getdata = false;
			var request = $.ajax({
				type: "POST",
				url: "check_proc.php",
				contentType: "application/x-www-form-urlencoded; charset=utf-8",
				data: 'type=nick&value='+$(this).val(),   
				dataType: "html"
			});
			request.done(function(msg) {   
				//$('#result').html(msg);   
				// getdata = msg;
				// console.log('request done : '+msg);
				updateNick(msg);
			});   
			   
			request.fail(function(jqXHR, textStatus) {   
				alert('Error');
				console.log( "Request failed: " + textStatus );   
				// getdata = false;
			});
			// console.log(getdata);
		});
		// 이메일 체크
		$('input[name=email1]').keyup(function(){
			$obj = $('input[name=email1]');
			$obj2 = $('input[name=email2]');
			var email_val = $obj.val()+'@'+$obj2.val();
			var regex=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
			if($obj.val() && $obj2.val()) {
				// 이메일 유효성 검사.
				if(regex.test(email_val) === false) {
					$obj.nextAll('.font').removeClass('green');
					$obj.nextAll('.font').addClass('red');
					$obj.nextAll('.font').html('<i style="margin:0;" class="check circle outline icon"></i>이메일 형식이 맞지 않습니다!');
				}
				else {
					var request = $.ajax({
						type: "POST",
						url: "check_proc.php",
						contentType: "application/x-www-form-urlencoded; charset=utf-8",
						data: 'type=email&value='+email_val,   
						dataType: "html"
					});
					request.done(function(msg) {   
						//$('#result').html(msg);   
						// getdata = msg;
						// console.log('request done : '+msg);
						updateEmail(msg);
					});   
					   
					request.fail(function(jqXHR, textStatus) {   
						alert('Error');
						console.log( "Request failed: " + textStatus );   
						// getdata = false;
					});
				}
			}
			// console.log(getdata);
		});
		$('input[name=email2]').keyup(function(){$('input[name=email1]').keyup();});


		// 닉네임 체크 도움 함수
		function updateNick(value) {
			// console.log(value);
			// 2글자 이하라면
			$obj = $('input[name=userid]');
			if($obj.val().length < 3) {
				$obj.next('.font').removeClass('green');
				$obj.next('.font').addClass('red');
				$obj.next('.font').html('<i style="margin:0;" class="check circle outline icon"></i>3자 이상으로 입력해 주세요.');
			// getdata 1(정상적인 값 받아옴)
			} else if(value=='success') {
				$obj.next('.font').removeClass('red');
				$obj.next('.font').addClass('green');
				$obj.next('.font').html('<i style="margin:0;" class="check circle icon"></i>중복된 닉네임이 없습니다.');
			} else {
				$obj.next('.font').removeClass('green');
				$obj.next('.font').addClass('red');
				$obj.next('.font').html('<i style="margin:0;" class="check circle outline icon"></i>중복된 닉네임이 있습니다.');
			}
		}

		// 닉네임 체크 도움 함수
		function updateEmail(value) {
			// console.log(value);
			$obj = $('input[name=email1]');
			$obj2 = $('input[name=email2]');
			if($obj.val() && $obj2.val()) {
				if(value=='success') {
					$obj.nextAll('.font').removeClass('red');
					$obj.nextAll('.font').addClass('green');
					$obj.nextAll('.font').html('<i style="margin:0;" class="check circle icon"></i>중복된 이메일이 없습니다.');
				} else {
					$obj.nextAll('.font').removeClass('green');
					$obj.nextAll('.font').addClass('red');
					$obj.nextAll('.font').html('<i style="margin:0;" class="check circle outline icon"></i>중복된 이메일이 있습니다! 혹시 이미 가입하셨나요? 그렇지 않다면 관리자에게 문의 해주세요.');
				}
			}
		}

	});
</script>
<div class="clear"></div>

<!-- style -->

<style type="text/css">


.regButton {
	-moz-box-shadow:inset 0px 1px 0px 0px #d9fbbe;
	-webkit-box-shadow:inset 0px 1px 0px 0px #d9fbbe;
	box-shadow:inset 0px 1px 0px 0px #d9fbbe;
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #b8e356), color-stop(1, #a5cc52));
	background:-moz-linear-gradient(top, #b8e356 5%, #a5cc52 100%);
	background:-webkit-linear-gradient(top, #b8e356 5%, #a5cc52 100%);
	background:-o-linear-gradient(top, #b8e356 5%, #a5cc52 100%);
	background:-ms-linear-gradient(top, #b8e356 5%, #a5cc52 100%);
	background:linear-gradient(to bottom, #b8e356 5%, #a5cc52 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#b8e356', endColorstr='#a5cc52',GradientType=0);
	background-color:#b8e356;
	-moz-border-radius:3px;
	-webkit-border-radius:3px;
	border-radius:3px;
	border:1px solid #83c41a;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-weight:bold;
	padding:12px 24px;
	margin: 10px 10px 0 0;
	text-decoration:none;
	text-shadow:0px 0px 1px rgba(0,0,0, 0.5);
	font-size: 12pt !important;
	line-height: 15pt !important;
}
.regButton:hover {
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #a5cc52), color-stop(1, #b8e356));
	background:-moz-linear-gradient(top, #a5cc52 5%, #b8e356 100%);
	background:-webkit-linear-gradient(top, #a5cc52 5%, #b8e356 100%);
	background:-o-linear-gradient(top, #a5cc52 5%, #b8e356 100%);
	background:-ms-linear-gradient(top, #a5cc52 5%, #b8e356 100%);
	background:linear-gradient(to bottom, #a5cc52 5%, #b8e356 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#a5cc52', endColorstr='#b8e356',GradientType=0);
	background-color:#a5cc52;
}
.regButton:active {
	position:relative;
	top:1px;
}
</style>


		</section>			<!-- 컨텐츠 컨테이너 종료 -->
	</div>


	<!-- 풋터 영역 -->
	<footer class="work"></footer>

	<footer class="main_footer">
		<section class="container">
			<div class="description float left">

				<div>
					
				    <a href="../about/company.php?PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">회사소개</a>
				    
					<a href="../about/privacy.php?PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">개인정보취급방침</a>
					<a href="../about/terms.php?PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">이용약관</a>
					<a href="javascript:customer01();">공지사항</a>
					<a href="../about/guide.php?PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">이용가이드</a>
					<a href="../customer/faq.php?b_id=002&PHPSESSID=185dbf63c0becc7ce2f7936c9f78e021">일반이용문의</a>
				</div>
				<div style="letter-spacing: -1px; margin-top: 10px; line-height:17px !important;">
					<b>크레벅스 대표</b> 김범수 <span class="bar">|</span> <b>사업자등록번호</b> 114-16-34644 <span class="bar">|</span> <b>통신판매업신고</b> 2016-서울강남-02115<br>
					<b>주소</b> 서울특별시 강남구 테헤란로 332, 2층(역삼동, 현정빌딩) <span class="bar">|</span> <b>TEL</b> 070-8777-0139 <span class="bar">|</span> <b>FAX</b> 02-6229-0139<br>
					Copyright <i class="icon copyright"></i>CREBUGS. All right reserved.
				</div>
			</div>
			<div class="right float customer" style="margin-top: 10px;">
				<h4 style="font-weight: bold; font-size: 12pt !important; line-height: 14pt !important;"><img src="../images/layout/headphone.png" width="15">크레벅스 고객센터</h4>
				<div style="margin: 4px 0;">주말 및 공휴일은 휴무입니다.</div>
				<div class="office_num" style="color: #2ace24; font-size: 14pt !important; line-height: 15pt !important; font-weight: bold;">070-8777-0139</div>
				<div>운영시간 <span style="color: #2ace24;">09:00~18:00</span></div>
			</div>
			<div class="clear"></div>
		</section>
	</footer>


<nav class="top_btn">
	<i class="icon arrow up"></i>
</nav>


<div id="mask"></div>
<div class="layer_request">
	<div class="request_tit"><img src="../images/layout/catogory_request_tit.png" alt="카테고리타이틀"></div><!--.request_tit-->
	<div class="request_subtit">원하시는 카테고리가 없으시다면 크레벅스에게 말해주세요!<br><small style="font-size: 8pt !important; line-height: 20pt !important;">ex) [게임]붉은보석, [컴퓨터]아이폰 어플리케이션 등</small></div><!--.request_subtit-->
	<div class="request_btn">
    	<input type="text" name="content" maxlength="18" autocomplete="off">
        <div class="btn green">전송하기</div>
    </div><!--.request_btn-->
    <div class="close layer">
    	<i class="icon remove"></i>
    </div>
</div>

<script type="text/javascript">

	$(function(){
		$('.btnCategory_request').click(function(){
	        //화면의 높이와 너비를 구한다.
	        var maskHeight = $(document).height();
	        var maskWidth = $(window).width();

	        //마스크의 높이와 너비를 화면 것으로 만들어 전체 화면을 채운다.
	        $('#mask').css({'width':maskWidth,'height':maskHeight});

	        //애니메이션 효과
	        $('#mask').fadeIn(500);
	        $('#mask').fadeTo(500,0.6);

	        $('html').css('overflow', 'hidden');
			$('.layer_request').fadeIn(1000);
			$('.layer_request').find('input').focus();
		});
		//검은 막을 눌렀을 때
		$('#mask').click(function () {
		    $(this).fadeOut(500);
		    $('.window').hide();
			$('html').css('overflow', 'auto');

			$('.layer_request').fadeOut(500);
		});
		$('.close.layer').click(function(){
			$('#mask').click();
		});
		$('.request_btn .btn.green').click(function(){
			var userno = '';
			var content = $('.layer_request > .request_btn > [name=content]').val();
			if (userno=='') {
				alert("로그인을 해주세요.");
				location.reload();
				return false;
			}
			else if(content=='') {
				alert("내용을 입력해 주세요.");
				location.reload();
				return false;
			}
			$.post("../product/process.php",{mode:"cate_request", userno: userno, content: content}, function(data) {
				// console.log(data);
				if(data!="Y"){
					alert("카테고리 요청에 실패했습니다. 다시 시도해주세요.");
					location.reload();
					return false;
				}
				else {
					alert("관리자에게 카테고리를 요청했습니다!\n적극적으로 수렴하겠습니다 ^-^");
					location.reload();
				}
			});
		});

		$('.top_btn').click(function(){
				$('html, body').animate({scrollTop:0}, '200', 'swing', function(){$(window).scroll();});
		});
			// 위치 재배열
		$(window).scroll(function(){
		    var tops = $(window).scrollTop();

		    // console.log('tops: '+tops);
		    // console.log('product_content: '+$('.main_content .product_content').width());

		    // console.log('footerHeight: '+footerHeight);

		    // var limitHeight = $(document).height() - $('.button-group').height() - 10 - tops;

		    if(tops<$('.main_content').first().offset().top) { //95
		    	// console.log('안 넘었다');
		        // element.css({'top':'', 'position':''}).css('right', '').css('left', '');
		        $('.top_btn').fadeOut('fast');

		    }
		    else {
		    	// console.log('넘었다');
	        	// element.css({'top':0, 'position':'fixed'}).css('left',($('.main_content .container').offset().left + $('.main_content .product_content.top').width() + 32));
	        	$('.top_btn').fadeIn('fast').css('right', ($('.main_content > .container').offset().left - 40)+'px');
		    }
		});
	});
</script>


<script src="../outdatedbrowser/outdatedbrowser.min.js"></script>

<script type="text/javascript">
//event listener: DOM ready
function addLoadEvent(func) {
    var oldonload = window.onload;
    if (typeof window.onload != 'function') {
        window.onload = func;
    } else {
        window.onload = function() {
            if (oldonload) {
                oldonload();
            }
            func();
        }
    }
}
//call plugin function after DOM ready
addLoadEvent(function(){
    outdatedBrowser({
        bgColor: '#f25648',
        color: '#ffffff',
        lowerThan: 'transform',
        languagePath: '../outdatedbrowser/lang/kr.html'
    })
});
</script>


<div id="outdated"></div>
</body>
</html>
